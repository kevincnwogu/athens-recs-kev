import { useState, useRef, useEffect, FormEvent, useMemo } from 'react';
import { 
  Sparkles, 
  MapPin, 
  Clock, 
  Globe, 
  Utensils, 
  ExternalLink,
  ChevronRight,
  Heart,
  PawPrint
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
interface Restaurant {
  id: string;
  number: string;
  name: string;
  genre: string;
  website: string;
  address: string;
  price: string;
  vibe: string;
  reservation: string;
  resClass: string;
  top3: string[];
  hours: string;
  color: string;
  isFavorite: boolean;
  bestFor: string;
}

// --- Data ---
const restaurants: Restaurant[] = [
  {
    id: "cali",
    number: "01",
    name: "Cali-N-Tito's",
    genre: "Latin American",
    website: "https://cali-n-titos.menu-world.com/menu",
    address: "1427 S Lumpkin St, Athens, GA 30605",
    price: "$ Budget-Friendly",
    vibe: "🎉 Festive Family Fun",
    reservation: "Walk-in — order at counter",
    resClass: "bg-blue-100 text-blue-800",
    top3: [
      "Cuban Sandwich (Criollo-style) — the #1 most-reviewed item",
      "Fish Burrito — massive, flavorful, and your friend's absolute favorite",
      "Lomo Saltado — Peruvian stir-fry steak, add egg & avocado"
    ],
    hours: "Saturday: 11:00 AM – 10:00 PM\nSunday: 11:00 AM – 9:00 PM",
    color: "#C8102E",
    isFavorite: true,
    bestFor: "Big groups, colorful outdoor patio energy, BYOB nights. Perfect for Ben to run around while Joe and Ali relax."
  },
  {
    id: "mamas",
    number: "02",
    name: "Mama's Boy",
    genre: "Southern Breakfast & Brunch",
    website: "https://www.mamasboyathens.com",
    address: "197 Oak St, Athens, GA 30601",
    price: "$$ Moderate",
    vibe: "☀️ Lazy Morning Vibes",
    reservation: "Recommended — can get busy on weekends",
    resClass: "bg-yellow-100 text-yellow-800",
    top3: [
      "Pulled Pork Bowl — w/ California fire sauce & eggs, legendary",
      "Peach French Toast — fresh, seasonal, absolutely delicious",
      "Housemade Biscuits — often called the best in Athens; pair w/ jam"
    ],
    hours: "Saturday: 7:00 AM – 2:30 PM\nSunday: 7:00 AM – 2:30 PM",
    color: "#E8A045",
    isFavorite: false,
    bestFor: "A slow, relaxed family breakfast before exploring downtown. Cozy, casual, and full of southern warmth."
  },
  {
    id: "theplace",
    number: "03",
    name: "The Place",
    genre: "American / Southern",
    website: "https://www.theplaceathens.com",
    address: "229 E Broad St, Athens, GA 30601",
    price: "$$ Moderate",
    vibe: "🏛️ UGA Campus Views",
    reservation: "Recommended for dinner on weekends",
    resClass: "bg-yellow-100 text-yellow-800",
    top3: [
      "Chicken & Waffles — the bacon addition takes it over the top",
      "Shrimp & Grits — a southern classic, done beautifully",
      "Bourbon Glazed Salmon — rich and crowd-pleasing"
    ],
    hours: "Saturday: 11:00 AM – 10:00 PM\nSunday: 10:00 AM – 2:00 PM, then 4:00 – 9:00 PM",
    color: "#4A7C9E",
    isFavorite: false,
    bestFor: "A nicer sit-down lunch or dinner with window views of UGA's North Campus and the Arch. Great for soaking in the college town atmosphere."
  },
  {
    id: "dawg",
    number: "04",
    name: "Dawg Gone Good BBQ",
    genre: "Southern BBQ",
    website: "https://dawggonegoodbbq.com",
    address: "224 W Hancock Ave, Athens, GA 30601",
    price: "$ Budget-Friendly",
    vibe: "🍖 No-Frills, All-Flavor",
    reservation: "Walk-in only — no reservations needed",
    resClass: "bg-blue-100 text-blue-800",
    top3: [
      "Sampler Platter — pulled pork, ribs, sausage, 2 sides",
      "Pulled Pork w/ Carolina Gold Sauce — moist, tender, a must",
      "Collard Greens & Baked Beans — standout sides, don't skip them"
    ],
    hours: "Saturday: 11:00 AM – 8:00 PM\nSunday: CLOSED — plan for Saturday!",
    color: "#8B3A2A",
    isFavorite: false,
    bestFor: "When the family is hungry and wants something hearty and unpretentious. Homey, charming, and some of the best BBQ in Athens."
  },
  {
    id: "lastresort",
    number: "05",
    name: "Last Resort Grill",
    genre: "Southwestern Southern",
    website: "https://lastresortgrill.com",
    address: "174–184 W Clayton St, Athens, GA 30601",
    price: "$$$ Upscale",
    vibe: "🕯️ Date Night / Special Occasion",
    reservation: "Strongly Recommended — fills up fast",
    resClass: "bg-red-100 text-red-800",
    top3: [
      "Short Rib — fall-off-the-bone, richly seasoned, one of their best",
      "Crab Cakes — a perennial favorite, well-crafted and fresh",
      "German Chocolate Cake — the dessert case is not to be missed"
    ],
    hours: "Saturday: 11:00 AM – 2:00 PM, 5:00 – 10:15 PM\nSunday: 11:00 AM – 2:00 PM, 5:00 – 9:00 PM",
    color: "#5C4A9E",
    isFavorite: false,
    bestFor: "The nicest dinner of the trip. A lively atmosphere and a true Athens institution. Great if Joe and Ali want a sophisticated meal."
  },
  {
    id: "south",
    number: "06",
    name: "South Kitchen + Bar",
    genre: "Elevated Southern",
    website: "https://southkitchenbar.com",
    address: "247 E Washington St, Suite 101, Athens, GA 30601",
    price: "$$ Moderate",
    vibe: "🏚️ Historic Brick Beauty",
    reservation: "Recommended for weekend dinner",
    resClass: "bg-yellow-100 text-yellow-800",
    top3: [
      "Duck Fat Tots — the legendary starter, crispy and addictive",
      "Low Country Shrimp & Grits — beautifully plated",
      "Nashville Hot Chicken Sandwich — bold heat, great crunch"
    ],
    hours: "Saturday: 10:00 AM – 11:00 PM\nSunday: 10:00 AM – 10:00 PM",
    color: "#2D6A4F",
    isFavorite: false,
    bestFor: "Dinner in a stunning exposed-brick building with arched windows. Upscale but not stuffy, a great spot for the whole family."
  },
  {
    id: "caferacer",
    number: "07",
    name: "Cafe Racer",
    genre: "Cafe / Breakfast / Donuts",
    website: "https://www.caferacer78.com/breakfast-menu",
    address: "2343 W Broad St, Athens, GA 30606",
    price: "$$ Moderate",
    vibe: "☕ Cool & Hip Morning Spot",
    reservation: "Walk-in — expect a short wait",
    resClass: "bg-blue-100 text-blue-800",
    top3: [
      "Breakfast Burrito — reviewers call it the best they've ever had",
      "Chicken Biscuit — fresh, flavorful, multiple creative toppings",
      "Specialty Donuts — fluffy, creative, Ben will love these!"
    ],
    hours: "Saturday: 6:00 AM – 2:00 PM, 5:00 – 10:00 PM\nSunday: 6:00 AM – 2:00 PM, 5:00 – 10:00 PM",
    color: "#222222",
    isFavorite: false,
    bestFor: "Early morning fuel before exploring Athens. Welcoming atmosphere, great coffee, and fun donuts."
  },
  {
    id: "clocked",
    number: "08",
    name: "Clocked!",
    genre: "Retro American Diner",
    website: "http://www.clockeddiner.com/",
    address: "259 W Washington St, Athens, GA 30601",
    price: "$$ Moderate",
    vibe: "🍔 Quirky Diner Fun for All Ages",
    reservation: "Walk-in — no reservations needed",
    resClass: "bg-green-100 text-green-800",
    top3: [
      "Peanut Butter Burger — sounds wild, tastes unbelievable",
      "Tater Tots w/ House Sauce — reviewers rave about these every time",
      "Garlic Parmesan Fries — addictive, generous portion"
    ],
    hours: "Saturday: 11:00 AM – 10:00 PM\nSunday: 11:00 AM – 10:00 PM",
    color: "#B8121A",
    isFavorite: false,
    bestFor: "Ben will absolutely love the retro sci-fi diner atmosphere — checkerboard floors, candlelit booths, vintage posters. A fun lunch stop."
  }
];

// --- App ---
export default function App() {
  const [activeFilter, setActiveFilter] = useState('All');
  const scrollRef = useRef<HTMLDivElement>(null);

  // Reset scroll position when filter changes
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollLeft = 0;
    }
  }, [activeFilter]);

  const filters = ['All', 'Cheap Eats', 'Walk-Ins', 'Breakfast / Brunch'];
  const filteredRestaurants = useMemo(() => {
    let list = restaurants.filter(res => {
      if (activeFilter === 'All') return true;
      if (activeFilter === 'Cheap Eats') return res.price.includes('$ Budget-Friendly') || res.price.includes('$ Budget');
      if (activeFilter === 'Walk-Ins') return res.reservation.toLowerCase().includes('walk-in');
      if (activeFilter === 'Breakfast / Brunch') return res.genre.toLowerCase().includes('breakfast') || res.genre.toLowerCase().includes('brunch');
      return true;
    });

    if (activeFilter !== 'All') {
      // Use true randomness for "more shuffled" feel
      const shuffled = [...list];
      for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
      }

      // STRICTLY ensure Cali-N-Tito's isn't first for filtered views
      if (shuffled.length > 1 && shuffled[0].id === 'cali') {
        const randomTarget = Math.floor(Math.random() * (shuffled.length - 1)) + 1;
        const temp = shuffled[0];
        shuffled[0] = shuffled[randomTarget];
        shuffled[randomTarget] = temp;
      }
      return shuffled;
    }
    
    return list;
  }, [activeFilter]);

  return (
    <div className="font-sans min-h-screen bg-bg-warm selection:bg-brand-gold/30 flex flex-col">
      {/* HEADER / HERO */}
      <header className="relative bg-brand-red text-white p-6 md:p-12 overflow-hidden shadow-lg border-b-2 border-black">
        <div className="absolute top-0 right-0 opacity-10 pointer-events-none -mt-4 -mr-4 select-none">
          <div className="text-[clamp(100px,20vw,240px)] font-black tracking-tighter uppercase leading-none">ATHENS</div>
        </div>
        
        <div className="max-w-7xl mx-auto relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-4">
              <span className="bg-brand-gold text-black text-[10px] font-black px-3 py-1 rounded tracking-[0.2em] uppercase shadow-sm">
                Weekend Food Guide
              </span>
            </div>
            
            <h1 className="font-black italic text-4xl md:text-6xl lg:text-7xl leading-[1] tracking-tighter">
              <span className="font-serif block md:inline mb-1 md:mb-0">Joe, Ali & Ben's</span>{" "}
              <span className="text-brand-gold not-italic uppercase">Eats</span>
            </h1>
          </div>

          <div className="md:text-right max-w-xs">
            <div className="inline-flex mb-4 md:justify-end">
              <motion.div 
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 5, repeat: Infinity }}
                className="bg-brand-gold/20 p-3 rounded-2xl border border-brand-gold/30"
              >
                <PawPrint className="w-8 h-8 text-brand-gold" />
              </motion.div>
            </div>
            <div className="mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-brand-gold">
              Swipe to the right to see your top 8 Athens food recs →
            </div>
            <p className="text-sm font-medium opacity-80 leading-snug">
              Your Athens food culture curated for family vibes, toddler energy, and UGA nostalgia by your favorite Double Dawg, Kev. Enjoy the weekend!
            </p>
          </div>
        </div>
      </header>

      {/* QUICK NAV / RESTAURANT LINKS */}
      <nav className="bg-white border-b-2 border-black flex overflow-x-auto nav-strip sticky top-0 z-40 bg-white/95 backdrop-blur-sm">
        <div className="flex divide-x divide-black/10 border-r border-black/10">
          {restaurants.map(res => (
            <a 
              key={res.id} 
              href={`#${res.id}`}
              className="px-6 py-4 whitespace-nowrap font-display text-xs tracking-widest text-[#111111]/60 hover:text-brand-red hover:bg-black/5 transition-all duration-200 uppercase font-black"
            >
              {res.number} • {res.name}
            </a>
          ))}
        </div>
      </nav>

      <div className="flex-1 flex flex-col lg:flex-row max-w-7xl mx-auto w-full">
        {/* MAIN FEED */}
        <main className="flex-1 px-4 md:px-8 py-10">
          {/* FILTERS */}
          <div className="flex flex-wrap items-center gap-3 mb-10">
            {filters.map(f => (
              <button
                id={`filter-${f.toLowerCase().replace(/\s+/g, '-')}`}
                key={f}
                onClick={() => setActiveFilter(f)}
                className={`px-6 py-2 rounded-lg text-[10px] font-black tracking-widest uppercase border-2 transition-all duration-300 ${
                  activeFilter === f 
                    ? 'bg-brand-red text-white border-black shadow-[3px_3px_0px_rgba(0,0,0,1)] -translate-x-0.5 -translate-y-0.5' 
                    : 'bg-white text-[#111111] border-black hover:bg-slate-50 shadow-[1px_1px_0px_rgba(0,0,0,1)]'
                }`}
              >
                {f}
              </button>
            ))}
          </div>

          {/* RESTAURANT LIST - Horizontal Swipe on all screens to match "Swipe to the right" */}
          <div 
            ref={scrollRef}
            className="flex overflow-x-auto snap-x snap-mandatory gap-8 pb-12 no-scrollbar scroll-smooth min-h-[500px]"
          >
            <AnimatePresence mode="popLayout" initial={false}>
              {filteredRestaurants.map((res) => (
                <motion.section
                  layout
                  initial={{ opacity: 0, scale: 0.8, x: 50 }}
                  animate={{ opacity: 1, scale: 1, x: 0 }}
                  exit={{ 
                    opacity: 0, 
                    scale: 0.8,
                    x: -50,
                    transition: { duration: 0.2 } 
                  }}
                  transition={{ 
                    type: "spring",
                    stiffness: 400,
                    damping: 40,
                    mass: 1,
                    layout: { duration: 0.35, ease: "easeOut" }
                  }}
                  key={res.id}
                  id={res.id}
                  className="group relative bg-white border-2 border-black p-6 flex flex-col shrink-0 w-[85vw] md:w-[400px] snap-center shadow-[6px_6px_0px_rgba(17,17,17,0.8)] hover:shadow-[10px_10px_0px_rgba(17,17,17,0.8)] transition-shadow duration-300"
                >
                  <div className="flex flex-col h-full">
                    <header className="mb-6">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex flex-col">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[9px] font-black tracking-[0.2em] uppercase px-2 py-0.5 border border-black/10 rounded" style={{ color: res.color, backgroundColor: `${res.color}10` }}>
                              {res.genre}
                            </span>
                            <span className="text-[9px] font-black tracking-[0.2em] uppercase text-slate-400">
                              {res.price}
                            </span>
                          </div>
                          <h2 className="text-2xl font-black tracking-tighter text-[#111111]">
                            {res.name}
                          </h2>
                        </div>
                        {res.isFavorite && (
                          <div className="text-brand-red">
                            <Heart className="w-5 h-5 fill-current" />
                          </div>
                        )}
                      </div>
                    </header>

                    <div className="flex-1 space-y-5 mb-6">
                      <div className="p-4 bg-bg-warm/40 rounded-lg border-2 border-black/5">
                        <h4 className="text-[9px] font-black uppercase text-brand-gold mb-2 tracking-widest">Recommended Vibe</h4>
                        <p className="text-sm italic font-medium text-slate-700 leading-relaxed">
                          {res.vibe} — {res.bestFor}
                        </p>
                      </div>

                      <div className="bg-white border-2 border-black/10 p-4 rounded-xl shadow-inner">
                        <span className="text-[9px] font-black uppercase text-slate-500 tracking-widest block mb-3 border-b border-black/5 pb-2">Top 3 Menu Reviews:</span>
                        <ul className="text-[11px] font-bold space-y-2">
                          {res.top3.map((item, i) => (
                            <li key={i} className="flex gap-3 items-start">
                              <div className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: res.color }}></div>
                              <span className="text-slate-800">{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="flex flex-col gap-2 text-[10px] font-bold text-slate-500">
                        <div className="flex items-center gap-3">
                          <MapPin className="w-4 h-4 text-brand-red shrink-0" />
                          <a 
                            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(res.address)}`} 
                            target="_blank" 
                            rel="noreferrer" 
                            className="text-blue-600 hover:underline inline-flex items-center gap-1 group/link"
                          >
                            <span className="leading-snug">{res.address}</span>
                            <ExternalLink className="w-3 h-3 shrink-0 transition-transform group-hover/link:translate-x-0.5" />
                          </a>
                        </div>
                        <div className="flex items-center gap-3">
                          <Clock className="w-4 h-4 text-brand-red shrink-0" />
                          <span className="whitespace-pre-line tracking-tight">{res.hours}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <Globe className="w-4 h-4 text-brand-red shrink-0" />
                          <a href={res.website} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline inline-flex items-center gap-1 group/link">
                            View Menu & Website
                            <ExternalLink className="w-3 h-3 transition-transform group-hover/link:translate-x-0.5" />
                          </a>
                        </div>
                      </div>
                    </div>

                    <footer className="mt-auto pt-5 border-t-2 border-black">
                      <div className="flex flex-col gap-1">
                        <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1">Reservation Status:</span>
                        <div className={`p-3 border-2 border-black text-[11px] font-black uppercase tracking-[0.1em] rounded-lg text-center shadow-[3px_3px_0px_rgba(0,0,0,1)] ${
                          res.reservation.toLowerCase().includes('recommended') || res.reservation.toLowerCase().includes('required')
                            ? 'bg-red-500 text-white'
                            : 'bg-green-500 text-white'
                        }`}>
                          {res.reservation}
                        </div>
                      </div>
                    </footer>
                  </div>
                </motion.section>
              ))}
            </AnimatePresence>
          </div>
        </main>

        {/* SIDEBAR */}
        <aside className="w-full lg:w-[340px] bg-[#111111] text-white p-6 md:p-10 flex flex-col border-l-2 border-black">
          <div className="sticky top-24">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 rounded-xl bg-brand-gold flex items-center justify-center text-2xl shadow-[4px_4px_0px_rgba(255,255,255,0.2)]">🍽️</div>
              <div>
                <h3 className="text-white font-black tracking-tight text-xl leading-none uppercase">Food Guide</h3>
                <span className="text-[10px] font-bold uppercase text-brand-gold tracking-[0.2em] mt-1 block">Joe, Ali & Ben</span>
              </div>
            </div>

            <div className="space-y-6 mb-10">
              <div className="bg-white/5 border-l-4 border-brand-gold p-5 rounded-r-xl">
                <h4 className="text-[10px] font-black uppercase text-brand-gold mb-2 tracking-widest">Guide Rules</h4>
                <p className="text-xs font-medium text-white/70 leading-relaxed">
                  8 hand-picked restaurants from a UGA double dawg who loves to eat and struggled to narrow down the list. Curated for the whole family, every mood, and every meal.
                </p>
              </div>

              <div className="bg-brand-red p-5 rounded-xl border-2 border-black shadow-[6px_6px_0px_rgba(255,255,255,0.1)]">
                <h4 className="text-[10px] font-black uppercase text-white mb-2 tracking-widest">Key Legend</h4>
                <div className="space-y-3 mt-3">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-500 border border-white/20 rounded"></div>
                    <span className="text-[10px] font-bold uppercase">Resy Required / Recommended</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 border border-white/20 rounded"></div>
                    <span className="text-[10px] font-bold uppercase">Walk-in Friendly</span>
                  </div>
                </div>
              </div>
            </div>


          </div>
        </aside>
      </div>

    </div>
  );
}
